//
//  GrocerySectionsViewController.swift
//  Kondaparthi_GroceryApp
//
//  Created by Student on 4/12/22.
//

import UIKit

class GrocerySectionsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return groceryArrayLst.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = grocerySectionsTableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        cell.textLabel?.text = groceryArrayLst[indexPath.row].section
        return cell
    }
    
    var groceryStore = Grocery()
    
    var groceryArrayLst = groceriesLists

    @IBOutlet weak var grocerySectionsTableView: UITableView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.title = "Grocery Sections"
        // Do any additional setup after loading the view.
        grocerySectionsTableView.delegate = self
        grocerySectionsTableView.dataSource = self
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let firstSegueConnectn = segue.identifier
        if firstSegueConnectn == "itemSegue"{
            let programOutpt = segue.destination as! GroceryItemsViewController
            programOutpt.items = groceryArrayLst[(grocerySectionsTableView.indexPathForSelectedRow?.row)!]

        }
    }


}

