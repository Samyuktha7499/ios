//
//  MovieData.swift
//  Kondaparthi_Movies
//
//  Created by Kondaparthi,Samyuktha on 4/28/22.
//

import Foundation
struct Movie{
    let title:String
    let image:UIImage
    let releasedYear:String
    let movieRating:String
    let boxOffice:String
    let cast:String
    let moviePlot:String
}
let movies : [Movie] = [
    Movie(title:"Boyhood",image:UIImage(named: "boyhood")!,releasedYear: "2014",movieRating: "7.9",boxOffice: "57.3M",cast: "",moviePlot: ""),
    Movie(title:"Mad Max: Fury Road",image:UIImage(named: "mad max")!,releasedYear: "2015",movieRating: "8.1",boxOffice: "375.6M",cast: "",moviePlot: ""),
    Movie(title:"Moonlight",image:UIImage(named: "moonlight")!,releasedYear: "2016",movieRating: "7.4",boxOffice: "65.3M",cast: "",moviePlot: ""),
    Movie(title:"Inception",image:UIImage(named: "inception")!,releasedYear: "2010",movieRating: "8.8",boxOffice: "836.8",cast: "",moviePlot: ""),
    Movie(title:"Slumdog Millionaire",image:UIImage(named: "slumdog millionaire")!,releasedYear: "2008",movieRating: "8",boxOffice: "378.1M",cast: "",moviePlot: ""),
   
]

struct Genre{
    let category:String
    var movies=[Movie]()
}
let genres : []
