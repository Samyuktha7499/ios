//
//  MoviesViewController.swift
//  Kondaparthi_Movies
//
//  Created by Kondaparthi,Samyuktha on 4/28/22.
//

import UIKit

class MoviesViewController: UIViewController {

    @IBOutlet weak var collectionViewOutlet: UICollectionView!
    
    
    @IBOutlet weak var titleOutlet: UILabel!
    
    @IBOutlet weak var movieRatingOutlet: UILabel!
    
    
    @IBOutlet weak var boxOfficeOutlet: UILabel!
    
    
    @IBOutlet weak var movieReleaseOutlet: UILabel!
    
    @IBOutlet weak var moviePlotOutlet: UILabel!
    
    @IBOutlet weak var castOutlet: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
