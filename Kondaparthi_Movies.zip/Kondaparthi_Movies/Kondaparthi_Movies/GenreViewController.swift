//
//  ViewController.swift
//  Kondaparthi_Movies
//
//  Created by student on 4/28/22.
//

import UIKit

class GenreViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return moviesTitleArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = genreTableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        cell.textLabel?.text = moviesTitleArray[indexPath.row].category
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "movieSegue"{
            let output = segue.destination as! MoviesViewController
            output.moviesNameArray = moviesTitleArray[(genreTableView.indexPathForSelectedRow!.row)].movies
            output.title_movie = moviesTitleArray[(genreTableView.indexPathForSelectedRow!.row)].category
        }
    }
    
    @IBOutlet weak var genreTableView: UITableView!
    
    var moviesTitleArray = moviesTypes
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.title = "Movies App"
        genreTableView.delegate = self
        genreTableView.dataSource = self
    }
}


