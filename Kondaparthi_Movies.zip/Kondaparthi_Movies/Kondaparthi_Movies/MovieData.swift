//
//  MovieData.swift
//  Kondaparthi_Movies
//
//  Created by student on 4/28/22.
//

import Foundation
import UIKit

struct Movies {
    
    var title:String
    var image:UIImage
    var releasedYear:String
    var movieRating:String
    var boxOffice:String
    var moviePlot:String
    var cast = [String]()

}

struct Genre {
    
    var category:String
    var movies = [Movies] ()

}

let Genre_Horror = Genre(category: "Horror",
                   movies: [
                    Movies(title: "The Haunting of Hill House", image: UIImage(named: "haunting of hill house")!, releasedYear: "2018", movieRating: "7.5", boxOffice: "$2M", moviePlot: "The Haunting of Hill House uses Shirley Jackson’s famous novel as metaphor.", cast: ["Victoria Pedretti","Kate Gordon"]),
                    Movies(title: "The Platform", image: UIImage(named: "theplatform")!, releasedYear: "2019", movieRating: "7", boxOffice: "$1,090,116", moviePlot: "A vertical prison with one cell per level. Two people per cell. Only one food platform.", cast: ["Alexandra Masangkay","Ivan Massague"]),
                    Movies(title: "Hush", image: UIImage(named: "hush")!, releasedYear: "2016", movieRating: "6.6", boxOffice: "$13.6 million", moviePlot: "A deaf and mute writer who retreated into the woods to live in silence when killer in window.", cast: ["Kate Gordon","John Howard ",]),
                    Movies(title: "The Conjuring", image: UIImage(named: "conjuring")!, releasedYear: "2013", movieRating: "7.5", boxOffice: "$319.5 million", moviePlot: "Paranormal investigators Ed and Lorraine Warren work to help a family terrorized.", cast: ["Patrick Joseph ","Vera Farmiga"]),
                    Movies(title: "The Conjuring 2", image: UIImage(named: "conjuring2")!, releasedYear: "2016", movieRating: "7.3", boxOffice: "$321.8 million", moviePlot: "In 1977, paranormal investigators Ed and Lorraine Warren come out of a self-imposed.", cast: ["Patrick Joseph ","Vera Ann Farmiga"])])

let Genre_Comedy = Genre(category: "Comedy",
                   movies: [
                    Movies(title: "Jathi Ratnalu", image: UIImage(named: "jathiratnalu")!, releasedYear: "2021", movieRating: "7.6", boxOffice: "40 million INR", moviePlot: "After being released from prison, three men start to plan their lives on the outside.", cast: ["Faria Abdullah","Naveen Polisetty"]),
                    Movies(title: "Chhichhore", image: UIImage(named: "Chhichhore")!, releasedYear: "2019", movieRating: "8.2", boxOffice: "150.36 crores ", moviePlot: "Following a group of friends from university as they progress into middle-age life.", cast: ["Sushant","Shradha kapoor",]),
                    Movies(title: "Ee Nagaraniki Emaindi", image: UIImage(named: "ene")!, releasedYear: "2018", movieRating: "7.9", boxOffice: "$179,263", moviePlot: "Childhood friends Vivek, Karthik, Kaushik, and Uppi hope for careers in film-making.", cast: ["vishwak","Sushanth","Naveen"]),
                    Movies(title: "Ready", image: UIImage(named: "ready")!, releasedYear: "2008", movieRating: "7.2", boxOffice: "170 million INR", moviePlot: "Chandu, an engineering student, lives an independent life. He falls in love with Pooja.", cast: ["Ram","Jenelia"]),
                    Movies(title: "Dubai Seenu", image: UIImage(named: "dubaiseenu")!, releasedYear: "2007", movieRating: "6.5", boxOffice: "₹13 crore", moviePlot: "A man aim in life is to fly to Dubai and earn tons of money.", cast: ["Ravi Teja","‎Nayantara"])])

let Genre_Crime = Genre(category: "Crime",
                   movies: [
                    Movies(title: "The GodFather", image: UIImage(named: "godfather")!, releasedYear: "1972", movieRating: "9.2", boxOffice: "$136.9 million", moviePlot: "The aging patriarch of an organized crime dynasty in postwar New York City.", cast: ["Al Pacino", "Marlon Brado"]),
                    Movies(title: "The GodFather 2", image: UIImage(named: "godfather2")!, releasedYear: "1974", movieRating: "9", boxOffice: "$57,385,823,", moviePlot: "The compelling sequel to The Godfather,contrasting the life of father and son.", cast: ["Al Pacino", "Marlon Brado"]),
                    Movies(title: "The GodFather 2", image: UIImage(named: "godfather3")!, releasedYear: "1990", movieRating: "7.6", boxOffice: "$136.9 million ", moviePlot: "Michael Corleone, now in his 60s, as he seeks to free his family from crime.", cast: ["Al Pacino", "Marlon Brado"]),
                    Movies(title: "Joker", image: UIImage(named: "joker")!, releasedYear: "2019", movieRating: "8.4", boxOffice: "$1.074 billion", moviePlot: "Forever alone in a crowd, failed comedian Arthur Fleck seeks connection.", cast: ["Joaquin Rafael Phoenix","Robert Anthony"]),
                    Movies(title: "The Wolf of Wall Street", image: UIImage(named: "wolf")!, releasedYear: "2013", movieRating: "8.2", boxOffice: "$392 million", moviePlot: "Based on the true story of Jordan Belfort, from his rise to a wealthy stock-broker living.", cast: ["Leonardo DiCaprio","Jordan Belfort"])])



let moviesTypes = [Genre_Horror,Genre_Comedy,Genre_Crime]
