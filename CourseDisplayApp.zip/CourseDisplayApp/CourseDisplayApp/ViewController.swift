//
//  ViewController.swift
//  CourseDisplayApp
//
//  Created by Kondaparthi,Samyuktha on 2/10/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var crsofrd: UILabel!
    @IBOutlet weak var crsttl: UILabel!
    @IBOutlet weak var crsnum: UILabel!
    @IBOutlet weak var ImageDisplay: UIImageView!
    @IBOutlet weak var PreviousButton: UIButton!
    @IBOutlet weak var NextButton: UIButton!
    
    let courses = [
        ["img01","44555","Network Security","Fall 2022"], ["img02","44643","iOS","Spring 2022"],
    ["img03","44656","Streaming Data","Summer 2022"]
    ]
    var imageNumber = 0
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //Load the details of the details (image,num,title,and sem) of the first (0th element) course
        // Previous button ids disabled
        
        PreviousButton.isEnabled = false;
        
        ImageDisplay.image = UIImage(named: courses[0][0])
        crsnum.text = courses[0][1]
        crsttl.text  = courses[0][2]
        crsofrd.text = courses[0][3]
        
    }

    @IBAction func NextButtonClicked(_ sender: Any) {
        //UI should be updated with the next course details
         imageNumber += 1
         updateUI(imageNumber)
         //previous button should be enabled
         PreviousButton.isEnabled = true
         //once reaching the end of courses array nextbutton should be disabled
         if (imageNumber == courses.count-1){
             NextButton.isEnabled = false
        
    }
    @IBAction func PreviousBottonClicked(_ sender: UIButton)
    {
       // next button should be enabled
        NextButton.isEnabled = true
        imageNumber -= 1
        updateUI(imageNumber)
        if (imageNumber == 0){
            PreviousButton.isEnabled = false
        }
    }
        func updateUI(_ imageNumber : Int ){
            ImageDisplay.image = UIImage(named: courses[imageNumber][0])
            crsnum.text = courses[imageNumber][1]
            crsttl.text = courses[imageNumber][2]
            crsofrd.text = courses[imageNumber][3]

        }
    }
    
    
}

