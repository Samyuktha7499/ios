//
//  ViewController.swift
//  Kondaparthi_SearchApp
//
//  Created by student on 3/3/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var searchButton: UIButton!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var prevButton: UIButton!
    
    @IBOutlet weak var nextButton: UIButton!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    @IBOutlet weak var resetButton: UIButton!
    
    var arr = [["black","blue","green","pink","red"],
    ["banff_national_park","k2","mount_everest","mount_huang","mount_kinabalu"],
    ["Lotus-Flower","Orchid","Rose","Sunflower","Dahlia"],
    ["background","404"]]
    
    var colours_array = ["colour","colors","black","blue","green","pink","white"]
    
    var mountains_array = ["mountains","banff_national_park","k2","mount_everest","mount_huang","mount_kinabalu"]
    
    var flowers_array = ["flowers","flower","Lotus-Flower","Orchid","Rose","Sunflower","Dahlia"]
    
    var var1 = 0
    var firstimage:Int!
    var secondimage:Int!
    var thirdimage:Int!
    var label1:Int!
    var label2:Int!
    var label3:Int!
    var content1:Int!
    var content2:Int!
    var content3:Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        prevButton.isHidden = true
        nextButton.isHidden = true
        searchButton.isEnabled = false
        resetButton.isHidden = true
        resultImage.image = UIImage(named: arr[3][0])
        topicInfoText.text = nil
    }

    @IBAction func searchTextField(_ sender: UITextField) {
        searchButton.isEnabled = true
        if(sender.text == ""){
            searchButton.isEnabled = false
        }
        else{
            prevButton.isEnabled = false
            nextButton.isEnabled = false
            searchButton.isEnabled = true
            resetButton.isHidden = false
    }
    }

    var colours = [["black","blue","green","pink","red"],["The color – or rather adsense of colour– black is often linked with negative associations, such as death, fear or sadness, according to the colour. Many ancient cultures believed that black was the color of mystery and of the mysterious ways and wisdom of God, historian Ellen Conroy wrote in her book (1921).","orchid, (family Orchidaceae), any of nearly 1,000 genera and more than 25,000 species of attractively flowered plants distributed throughout the world, especially in wet tropics. Orchidaceae is a member of Asparagales, an order of monocotyledonous flowering plants that also includes the asparagus and iris families.","A rose is a woody perennial flowering plant of the genus Rosa, in the family Rosaceae, or the flower it bears. There are over three hundred species and tens of thousands of cultivars.[citation needed] They form a group of plants that can be erect shrubs, climbing, or trailing, with stems that are often armed with sharp prickles.","The botanical name is Helianthus. The Greek word helios means sun and anthos means flower. It is aptly named after the sun which it resembles. Sunflowers have a large flower head, usually with a large.","Dahlias grow from one to five feet tall. Flowers come in every color except blue, and the form is varied: peony-like; anemone-flowered; singles; shaggy mops; formal, ball-shaped; and twisted, curled petals. The flowers are carried on long stems above the erect plants."]]
    
    var mountains=[["banff_national_park","k2","mount_everest","mount_huang","mount_kinabalu"],["Banff National Park is Canada’s oldest national park, established in 1885 in the Rocky Mountains and one North America’s most visited parks. Banff’s mountains exhibit several different shapes that have been influenced by the composition of rock deposits, layers, and their structure. The 3,618 meter (11,870 ft) high Mount Assiniboine has been shaped by glacial erosion that has left a sharp peak.","With a peak elevation of 8,611 meters (28,251 ft), K2 is the second-highest mountain on Earth, after Mount Everest. The mountain is part of the Karakoram range, located on the border between China and Pakistan. K2 is also known as the Savage Mountain due to the difficulty of ascent and one of the highest fatality rate for those who climb it. K2 is notable for its local relief as well as its total height.","At 8,848 meters (29,029 ft), Mount Everest is the highest mountain on Earth. It is located on the border between Nepal and Tibet. The highest mountain in the world attracts climbers of all levels, from well experienced mountaineers to novice climbers willing to pay substantial sums to professional mountain guides to complete a successful climb.","Mount Huang is a mountain range in eastern China also known as Huangshan. The area is well known for its scenery, sunsets, peculiarly-shaped granite peaks and views of the clouds from above. Mount Huang is a frequent subject of traditional Chinese paintings and literature, as well as modern photography.","With a summit height at 4,095 meters (13,435 ft), Mount Kinabalu is the highest mountain in Borneo. The mountain is known worldwide for its tremendous botanical and biological species biodiversity. Over 600 species of ferns, 326 species of birds, and 100 mammalian species have been identified at Mount Kinabalu and its surrounding."]]

    var flowers = [["Lotus-Flower","Orchid","Rose","Sunflower","Dahlia"],["The lotus flower is an aquatic perennial. Sometimes mistaken for the water-lily, the lotus has a distinctively different structure. It also only comes in pink hues or white, whereas the lily comes in many different colors. The roots are implanted in the soil of a river or pond, and the leaves float on the surface. In some research reports, the lotus can control the temperature of itself just like humans and animals can.","According to Conroy, the primary association of the color blue for most of recorded history was with truth a meaning that leaves a remnant in our language in the phrase true blue. This was because blue is the color of a calm and clear sky, and it is in calm reflection that leads to truth.Today, though, blue mainly conveys sadness and despair. When you've got the blues, you're down in the dumps.","The color of the Heart chakra, also known as Anahata. This chakra is located at the center of the chest area and is linked to this entire area, the heart, lungs, circulatory system, and cardiac plexus. The Heart Chakra bridges the gap between the physical and spiritual worlds. Opening the Heart chakra allows a person to love more, empathize, and feel compassion.","The color pink represents compassion, nurturing and love. It relates to unconditional love and understanding, and the giving and receiving of nurturing. A combination of red and white, pink contains the need for action of red, helping it to achieve the potential for success and insight offered by white. It is the passion and power of red softened with the purity, openness and completeness of white.","Red is a rich color with an even richer history. Use of the pigment can be traced way back to Ancient Egypt where it was considered both a color of vitality and celebration, as well as evil and destruction. From here on, red was a staple hue throughout history, used in ancient Grecian murals."]]

    @IBAction func searchButtonAction(_ sender: UIButton) {
        firstimage = 0
        secondimage = 0
        thirdimage = 0
        label1 = 0
        label2 = 0
        label3 = 0
        content1 = 0
        content2 = 0
        content3 = 0
        prevButton.isHidden = false
        nextButton.isHidden = false
        prevButton.isEnabled = false
        nextButton.isEnabled = false
        resetButton.isEnabled = true
        
        if(colours_array.contains(searchTextField.text!)){
            nextButton.isEnabled = true
            prevButton.isEnabled = false
            resultImage.image = UIImage(named: arr[0][firstimage])
            //imageName.text = actor[0][label1]
            var1 = 1
            topicInfoText.text = colours[1][content1]
        }
        else if(mountains_array.contains(searchTextField.text!)){
            nextButton.isEnabled = true
            prevButton.isEnabled = false
            resultImage.image = UIImage(named: arr[1][secondimage])
            //imageName.text = book[0][label2]
            var1 = 2
            topicInfoText.text = mountains[1][content2]
        }
        else if(flowers_array.contains(searchTextField.text!)){
            nextButton.isEnabled = true
            prevButton.isEnabled = false
            resultImage.image = UIImage(named: arr[2][thirdimage])
            //imageName.text = book[0][label3]
            var1 = 3
            topicInfoText.text = flowers[1][content3]
        }
        else{
            resultImage.image = UIImage(named: arr[3][1])
//            resultImage.image = nil
            topicInfoText.text = nil
            //imageName.text = nil
            prevButton.isHidden = true
            nextButton.isHidden = true
            resetButton.isEnabled = true
        }
    }
    

    @IBAction func ShowPrevImageBtn(_ sender: UIButton) {
        if(var1 == 1){
            firstimage -= 1
            label1 -= 1
            content1 -= 1
            dataUpdate(imgNo: firstimage)
        }
        if(var1 == 2){
            secondimage -= 1
            label2 -= 1
            content2 -= 1
            dataUpdate(imgNo: secondimage)
        }
        if(var1 == 3){
            thirdimage -= 1
            label3 -= 1
            content3 -= 1
            dataUpdate(imgNo: thirdimage)
        }
    }
    
    
    @IBAction func showNextImagesBtn(_ sender: UIButton) {
        if(var1 == 1){
            firstimage += 1
            label1 += 1
            content1 += 1
            dataUpdate(imgNo: firstimage)
        }
        if(var1 == 2){
            secondimage += 1
            label2 += 1
            content2 += 1
            dataUpdate(imgNo: secondimage)
        }
        if(var1 == 3){
            thirdimage += 1
            label3 += 1
            content3 += 1
            dataUpdate(imgNo: thirdimage)
        }
    }
    
    
    @IBAction func resetButton(_ sender: UIButton) {
        prevButton.isHidden = true
        nextButton.isHidden = true
        topicInfoText.text = nil
        resetButton.isHidden = true
        searchTextField.text = ""
        resultImage.image = UIImage(named: arr[3][0])
        searchButton.isEnabled=false
    }

    func dataUpdate(imgNo: Int){
        if(var1 == 1){
            if firstimage == arr[0].count-1 {
                nextButton.isEnabled = false
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[0][firstimage])
                //imageName.text = actor[0][label1]
                topicInfoText.text = flowers[1][content1]
            }
            else if(firstimage == 0){
                prevButton.isEnabled = false
                nextButton.isEnabled = true
                resultImage.image = UIImage(named: arr[0][firstimage])
                //imageName.text = actor[0][label1]
                topicInfoText.text = flowers[1][content1]
            }
            else{
                nextButton.isEnabled = true
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[0][firstimage])
                //imageName.text = actor[0][label1]
                topicInfoText.text = flowers[1][content1]
            }
        }
        if(var1 == 2){
            if secondimage == arr[1].count-1 {
                nextButton.isEnabled = false
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[1][secondimage])
                //imageName.text = book[0][label2]
                topicInfoText.text = mountains[1][content2]
            }
            else if(secondimage == 0){
                prevButton.isEnabled = false
                nextButton.isEnabled = true
                resultImage.image = UIImage(named: arr[1][secondimage])
                //imageName.text = book[0][label2]
                topicInfoText.text = mountains[1][content2]
            }
            else{
                nextButton.isEnabled = true
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[1][secondimage])
                //imageName.text = book[0][label2]
                topicInfoText.text = mountains[1][content2]
            }
        }
        if(var1 == 3){
            if thirdimage == arr[1].count-1 {
                nextButton.isEnabled = false
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[2][thirdimage])
                //imageName.text = animal[0][label3]
                topicInfoText.text = colours[1][content3]
            }
            else if(thirdimage == 0){
                prevButton.isEnabled = false
                nextButton.isEnabled = true
                resultImage.image = UIImage(named: arr[2][thirdimage])
                //imageName.text = animal[0][label3]
                topicInfoText.text = colours[1][content3]
            }
            else{
                nextButton.isEnabled = true
                prevButton.isEnabled = true
                resultImage.image = UIImage(named: arr[2][thirdimage])
                //imageName.text = animal[0][label3]
                topicInfoText.text = colours[1][content3]
            }
        }
    }
}
